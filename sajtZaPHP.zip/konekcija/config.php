<?php
 define("IMESERVERA","localhost");
 define("USERNAME","root");
 define("PASSWORD","");
 define("IMEBAZE","ogani");
