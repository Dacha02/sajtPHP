<section
  class="breadcrumb-section set-bg bg-size"
  data-setbg="img/breadcrumb.jpg"
>
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <div class="breadcrumb__text">
          <h2>Ogani Shop</h2>
          <div class="breadcrumb__option">
            <a href="./index.php">Početna</a>
            <span>Shop</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>